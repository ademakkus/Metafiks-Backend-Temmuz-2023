﻿namespace ThisKeywordOrnek2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Calisan calisan = new Calisan(1, "Adem AKKUŞ", "Yazılım", 25000);
            calisan.Yazdir();
             Calisan calisan2 = new Calisan(2, "Harun Yeni", "Muhasebe", 35000);
            calisan2.Yazdir();
            Calisan calisan3 = new Calisan(3, "Elif TUZLUCA", "Test", 30000);
            calisan3.Yazdir();
            //
            List<Calisan> calisanlar = new List<Calisan>();
            calisanlar.Add(calisan);
          
            Console.ReadKey();
        }
    }
}