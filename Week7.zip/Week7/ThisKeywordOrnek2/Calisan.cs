﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThisKeywordOrnek2
{
    public class Calisan
    {
        private int id;
        private string adSoyad;
        private string departman;
        private double maas;
        public Calisan(int id,string adSoyad,string departman,double maas)
        {
            this.id =id;
            this.adSoyad = adSoyad;
            this.departman = departman;
            this.maas = maas;
        }
        public void Yazdir()
        {
            Console.WriteLine("----ÇALIŞAN BİLGİLERİ----");
            Console.WriteLine($"ID:{this.id}");
            Console.WriteLine($"Ad Soyad:{this.adSoyad}");
            Console.WriteLine($"Çalıştığı Birim:{this.departman}");
            Console.WriteLine($"Maaşı:{this.maas}");
        }
    }
}
