﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassOrnek
{
    public class Ev
    {
        //field:alan
        public string turu;
        public int odaSayisi;
        public bool kiralikMi;
        public double metreKaresi;
        public string aciklama;
        //metot
        public void BilgileriYazdir()
        {
            string kiralikDurum;
            //if (kiralikMi)
            //    kiralikDurum = "Evet";
            //else
            //    kiralikDurum = "Hayır";
            //ternary operatörü kullanarak
            kiralikDurum = (kiralikMi) ?"Evet":"Hayır";
            Console.WriteLine("--- EV BİLGİLERİ-----");
            Console.WriteLine($"Türü:{turu}");
            Console.WriteLine($"Oda Sayısı:{odaSayisi}");
           // Console.WriteLine($"Kiralık DUrumu:{kiralikMi}");
            Console.WriteLine($"Kiralık Durumu:{kiralikDurum}");
            Console.WriteLine($"Metre Karesi:{metreKaresi}");
            Console.WriteLine($"Açıklama:{aciklama}");
        }
    }
}
