﻿namespace ClassOrnek
{
 
    internal class Program
    {
        static void Main(string[] args)
        {
            Ev ev=new Ev(); //boş nesne oluştu.
            ev.turu = "Konut";
            ev.odaSayisi = 3;
            ev.kiralikMi = true;
            ev.metreKaresi = 135;
            ev.aciklama = "Sifir ayarında 35 yıllık daire. deniz manzaları Ankara da ev";
            ev.BilgileriYazdir();

           // Console.WriteLine(ev.odaSayisi);

            Console.ReadKey();
        }
    }
}