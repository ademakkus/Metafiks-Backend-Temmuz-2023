﻿namespace DefaultConstructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Koordinat koordinat = new Koordinat();
            Console.WriteLine(koordinat.x);
            Console.WriteLine(koordinat.y);
            //
            Koordinat krd2 = new Koordinat(22, 33);
            Console.WriteLine(krd2.x);
            Console.WriteLine(krd2.y);
            //
            Koordinat krd3 = new Koordinat(krd2);
            Console.WriteLine(krd3.x);
            Console.WriteLine(krd3.y);
            Console.ReadKey();
        }
    }
}