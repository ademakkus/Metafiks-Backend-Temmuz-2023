﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefaultConstructor
{
    public class Koordinat
    {
        public int x;
        public int y;
        public Koordinat() //default constructor
        {
            Console.WriteLine("default contructor çalıştı.");
             this.x = 10;
            // x = 10;
            this.y = 20;
            //y = 20;
        }
        public Koordinat(int x, int y) //parametreli constructor
        {
            Console.WriteLine("\nparametreli kurucu çağrıldı.");
            this.x = x;
            this.y = y;
        }
        public Koordinat (Koordinat krd) //copy constructor
        {
            Console.WriteLine("\nnesne paramtre*****");
            this.x = krd.x;
            this.y = krd.y;
        }
    }
}
