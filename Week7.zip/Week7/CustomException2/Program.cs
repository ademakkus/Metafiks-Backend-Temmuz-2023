﻿namespace CustomException2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            byte sayi;
            try
            {
                Console.Write("Bir sayı giriniz:");
                sayi = Convert.ToByte(Console.ReadLine());
            }
            catch (FormatException fexc)
            {

               // Console.WriteLine($"orjinal hata mesajı:{fexc.Message}");
                Console.WriteLine("Sayısal  değer giriniz.");
            }
            catch(OverflowException oexc)
            {
                //Console.WriteLine($"orjinal hata mesajı:{oexc.Message}");
                Console.WriteLine("değer  0 - 255 aralığında olmalıdır.");
            }

            Console.ReadKey();
        }
    }
}