﻿namespace BaseOrnek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Calisan calisan = new Calisan("Adem AKKUŞ","Bilgisayar Mühendisi");

            Console.ReadKey();
        }
    }
}