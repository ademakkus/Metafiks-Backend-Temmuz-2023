﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseOrnek
{
    public class Calisan : Kisi
    {
        //public Calisan(string mesaj)
        //{
        //    Console.WriteLine(mesaj);
        //}
        //public Calisan() : this("Kendi krucu metodunu çalıştırır.");
        //{
        //    Console.WriteLine("kendi kurucu metot");
        //}
        public Calisan(string ad, string meslek) : base(ad)
        {
            Console.WriteLine($"Benim mesleğim:{meslek}");
        }
    }
}

