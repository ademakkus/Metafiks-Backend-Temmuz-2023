﻿namespace ClassOrnek2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dikdortgen dikdortgen = new Dikdortgen();
            dikdortgen.en = 10;
            dikdortgen.boy = 20;
           //int sonuc= dikdortgen.AlanHesapla();
            //dikdortgen.CevreHesapla();
            dikdortgen.BilgileriYazdir();
            Dikdortgen d2=new Dikdortgen();
            d2.BilgileriYazdir();

            //
            Dikdortgen d3 = new Dikdortgen(12, 23);
            d3.BilgileriYazdir();
            Console.ReadKey();
        }
    }
}