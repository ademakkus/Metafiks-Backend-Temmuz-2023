﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassOrnek2
{
    /// <summary>
    /// Dikdörtgen Sınıfı.
    /// </summary>
    public class Dikdortgen
    {
        public int en;
        public int boy;
        /// <summary>
        /// Dikdörtgenin alanını hesaplayan metot
        /// </summary>
        /// <returns>int alan</returns>
        public Dikdortgen() //default constructor
        {
            en = 1;
            boy = 1;
        }
        public Dikdortgen(int en,int boy) //parametreli constructor
        {
           this.en= en;
            this.boy = boy;
        }
        public int AlanHesapla()
        {
            int alan = en * boy;
            return alan;
        }
        /// <summary>
        /// Dikdörgenin çevresini hesaplayan metot
        /// </summary>
        /// <returns>int cevre</returns>
        public int CevreHesapla()
        {
            int cevre = 2 * (en + boy);
            return cevre;
        }
        /// <summary>
        /// Dikdörtgenin bilgilerini yazdıran metot.
        /// </summary>
        public void BilgileriYazdir()
        {
            Console.WriteLine("--DİKDÖRTGEN BİLGİLERİ--");
            Console.WriteLine($"En={en}");
            Console.WriteLine($"Boy={boy}");
            Console.WriteLine($"Çevresi={CevreHesapla()}");
            Console.WriteLine($"Alanı={AlanHesapla()}");
        }

    }
}
