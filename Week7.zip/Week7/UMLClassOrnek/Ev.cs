﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UMLClassOrnek
{
    public class Ev
    {
        string turu;
        int odaSayisi;
        private double metrekare;
        bool kiralikMi;
        string aciklama;

        public Ev()
        {
            throw new System.NotImplementedException();
        }

        public void BilgileriYazdir()
        {

        }

        public void KiraHesapla()
        {
            throw new System.NotImplementedException();
        }
    }
}