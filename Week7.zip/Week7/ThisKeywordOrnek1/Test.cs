﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThisKeywordOrnek1
{
    public class Test
    {
        int numara;
        public Test(int numara)
        {
            this.numara = numara;
            Console.WriteLine($"tihs objesi:{this}");
        }
    }
}
