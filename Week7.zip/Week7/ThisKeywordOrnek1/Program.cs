﻿namespace ThisKeywordOrnek1
{
    static internal class Program
    {
       
        static void Main(string[] args)
        {
            Test test = new Test(10);
            Console.WriteLine($"test objesi:{test}");
           
            

            Console.ReadKey();
        }
    }
}