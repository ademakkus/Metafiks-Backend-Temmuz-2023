﻿namespace CustomException
{
    //
    public class SifiraBolme : Exception
    {
        public SifiraBolme() //constructor:kurucu metot
        {
            Console.WriteLine("Sıfıra bölme hatası oluştu.");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            double pay=1, payda=1,sonuc;
            try
            {
                Console.Write("Pay değerini giriniz:");
                pay = Convert.ToDouble(Console.ReadLine());
                Console.Write("Payda değerini giriniz:");
                payda = Convert.ToDouble(Console.ReadLine());
                sonuc = BolmeIslemi(pay, payda);

            }
            catch (Exception exc)
            {

                Console.WriteLine($"Hata Mesajı:{exc.Message}");
            }
            Console.ReadKey();
        }
        public static double BolmeIslemi(double pay, double payda)
        {
            if (payda == 0)
                throw new SifiraBolme();
            return pay / payda;
        }
    }

    //
}