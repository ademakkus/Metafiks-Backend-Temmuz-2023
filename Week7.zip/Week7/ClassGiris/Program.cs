﻿namespace ClassGiris
{
    
    internal class Program
    {
        static void Main(string[] args)
        {
            //Ev ev;
         
            Ev ev = new Ev(); //ev nesnesi
            ev.turu = "Konut";
            ev.odaSayisi = 3;
            ev.metreKare = 140;
            ev.kiralikMi = false;
            ev.aciklama = "Sıfır ayarında 35 yıllık deniz manzaralı Ankarada lüks ev";
            //metodu çağıralım
            ev.BilgileriYazdir();
            //Console.WriteLine(ev.odaSayisi);
           Ev isyeri=new Ev();
            isyeri.turu = "Dükkan";
            isyeri.odaSayisi = 4;
            isyeri.metreKare = 350;
            isyeri.kiralikMi = true;
            isyeri.aciklama = "Marketelere uygun kiralık dükkan";
            isyeri.BilgileriYazdir();
            Console.ReadKey();
        }
    }
}