﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassGiris
{
    public class Ev
    {
        //fields:alanlar,sınıf değişkenleri
        //c# herşeyin bir erişim belirleyicisi vardır.
        //field varsayılan erişim belirleyicisi private
        public string turu;
        public int odaSayisi;
        public bool kiralikMi;
        public double metreKare;
        public string aciklama;

        /// <summary>
        /// Ev nesnesinin bilgilerini yazdırır.
        /// </summary>
        public void BilgileriYazdir() //metot
        {
            string durum;
            //if (kiralikMi)
            //    durum = "Evet";
            //else
            //    durum = "Hayır";
            durum = (kiralikMi) ? "Evet" : "Hayır";
            Console.WriteLine("---EV BİLGİLERİ--");
            Console.WriteLine($"Türü:{turu}");
            Console.WriteLine($"Oda Sayısı:{odaSayisi}");

            //Console.WriteLine($"Kiralik Durumu:{kiralikMi}");
            Console.WriteLine($"Kiralik Durumu:{durum}");

            Console.WriteLine($"Metre Karesi:{metreKare}");
            Console.WriteLine($"Açıklama:{aciklama}");

        }
    }
}
