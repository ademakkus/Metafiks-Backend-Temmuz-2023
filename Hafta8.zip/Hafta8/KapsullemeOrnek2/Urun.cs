﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KapsullemeOrnek2
{
    public class Urun
    {
        //fields:alanlar
        private string urunAdi;
        private string urunKodu;
        private double urunFiyati;
        //properties:özellikler
        public string UrunAdi
        {
            get { return urunAdi; }
            set
            {
                if (value == null || value.Length == 0 || value == "")
                    urunAdi = "isimsiz";
                else
                    urunAdi = value;
            }
        }
        public string UrunKodu
        {
            get { return urunKodu.ToUpper(); }
            set
            {
                Random random = new Random();
                urunKodu = value.ToString() + "-" + random.Next(10000, 99999);
            }
        }
        public double UrunFiyati
        {
            get { return urunFiyati; }
            set 
            {
                if (value <= 0)
                    urunFiyati = 1.00;
                else
                    urunFiyati=Math.Round(value, 2);
            }
        }
    }
}
