﻿namespace ConstructorOrnek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Test test2 = new Test();
            Test test=new Test("Adem AKKUŞ");

            //int sayi=12;
            //Console.WriteLine(sayi);
            Console.WriteLine(test.deger);
            Console.ReadKey();
        }
    }
}