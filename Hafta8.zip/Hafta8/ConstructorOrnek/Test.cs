﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorOrnek
{
    public class Test
    {
        string ad;
        public int deger=12;
        public Test() //default constructor
        {
            Console.WriteLine("default kurucu metot");
        }
        public Test(string ad)
        {
            Console.WriteLine(ad);
        }
    }
}
