﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace PropertyOrnek
{
    public class Kisi
    {
        //field:alan,sınıf değişkeni
        private string ad;
        private double maas;
        private int yas = 10;
       
        //property:özellik
        public string Ad
        {
            get { return ad; }  //değer okuma

            set
            {
                if (value == null)
                    ad = "Adsız";
                else
                    ad = value;
            }
        }
        public double Maas
        {
            get { return maas; }
            set
            {
                if (value < 0)
                    maas = 0;
                else
                    maas = value;

            }

        }
        public int Yas
        {
            get { return yas; }
        }

        private string sicilNo;
        public string SicilNo
        {
            get { return sicilNo; }
            set
            {
                Random random = new Random();
                sicilNo=value.ToString()+"-"+random.Next(1000,9999);
            }
        }
    }
}
