﻿namespace PropertyOrnek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Kisi kisi = new Kisi();
            kisi.Ad = "Adem AKKUŞ";
            Console.WriteLine(kisi.Ad);
            kisi.Maas = 10000;
            //kisi.Yas = 122;
            kisi.SicilNo = "AA";
            Console.WriteLine(kisi.Maas);
            Console.WriteLine(kisi.Yas);
            Console.WriteLine(kisi.SicilNo);
            Console.ReadKey();
        }
    }
}