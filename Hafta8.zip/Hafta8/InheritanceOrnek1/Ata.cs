﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceOrnek1
{
    public class Ata
    {
        public string ataAlan="ata sınıfı alan";
        public void MetotAta(string deger)
        {
            Console.WriteLine($"Ata sınıf MetotAta :{deger}");
        }
    }
}
