﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceOrnek1
{
    public class Cocuk:Ata
    {
        public string cocukAlan="çocuk sınıf alan";
        public void MetotCocuk(string deger)
        {
            Console.WriteLine($"Cocuk sınıf MetotCocuk :{deger}");
        }
    }
}
