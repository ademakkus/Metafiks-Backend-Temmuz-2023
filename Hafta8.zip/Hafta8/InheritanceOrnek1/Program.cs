﻿namespace InheritanceOrnek1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*** Ata sınıfı ****");
            Ata ata=new Ata();
            ata.ataAlan = "ata sınıf alanı";
            Console.WriteLine(ata.ataAlan);
            ata.MetotAta("değer");
            //
            Console.WriteLine("---Çocuk Sınıfı----");
            Cocuk cocuk = new Cocuk();
            Console.WriteLine(cocuk.cocukAlan);
            cocuk.MetotCocuk("deger2");
            Console.WriteLine(cocuk.ataAlan);
            cocuk.MetotAta("ddded");
            Console.ReadKey();
        }
    }
}