﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefaultConstructor
{

    //erişim belirleyicisi:access modifier
    //public, private, protected, internal
    //sınıflarda varsayılan erişim belirleyici internal
    //sınıf üyelerinin (fields,properties, metot) private
    public class Koordinat
    {
      private  int x;
      private  int y;
        public Koordinat() //default constructor
        {
            x = 1;
            y = 1;
            Console.WriteLine($"x={x}, y={y}");
        }
    }
}
