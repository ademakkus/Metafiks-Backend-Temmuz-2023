﻿namespace DefaultConstructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Koordinat krd = new Koordinat();
           
            Console.ReadKey();
        }
    }
}