﻿namespace AutoPropertyOrnek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Kisi kisi = new Kisi();
            kisi.Ad = "Adem AKKUŞ";
            kisi.Id = 1;
            kisi.Maas = 25000.25;
            Console.WriteLine(kisi.Id);
            Console.WriteLine(kisi.Ad);
            Console.WriteLine(kisi.Maas);
            Program program = new Program();
            program.ToString();
            Console.ReadKey();
        }
    }
}