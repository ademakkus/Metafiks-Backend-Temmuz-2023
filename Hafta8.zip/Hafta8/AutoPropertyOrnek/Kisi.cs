﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoPropertyOrnek
{
    public class Kisi
    {
        ////field
        //private string ad;
        ////property
        //public string Ad
        //{
        //    get { return ad; }
        //    set { ad = value; }
        //}
        //auto property
        //public string Ad { get; set; }
        //field
        //private int id;
        ////property
        //public int Id
        //{
        //    get { return id; }
        //    set { id = value;
        //}
        //auto property
        public int Id { get; set; }
        public string Ad { get; set; }
        public double Maas { get; set; }
        public char Cinsiyet { get; set; }


    }
}
