﻿namespace KalitimOrnek1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cocuk cocuk = new Cocuk();
            cocuk.CocukMetot(cocuk.cocukAlan);
            cocuk.CocukMetot(cocuk.ataAlan);
            cocuk.AtaMetot(cocuk.cocukAlan);
            cocuk.AtaMetot(cocuk.ataAlan);
           
            Console.ReadKey();
        }
    }
}