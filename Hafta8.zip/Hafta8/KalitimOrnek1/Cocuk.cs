﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KalitimOrnek1
{
    public class Cocuk:Ata // : kaltımı ifade eder
    {
        public string cocukAlan="çocuk sınıfı alan değeri";
        public void CocukMetot(string deger)
        {
            Console.WriteLine($"Çocuk sınıf metodu:{cocukAlan}");
        }
        public Cocuk()
        {
            Console.WriteLine("Çocuk sınıfı kurucu mmetot");
        }
    }
}
