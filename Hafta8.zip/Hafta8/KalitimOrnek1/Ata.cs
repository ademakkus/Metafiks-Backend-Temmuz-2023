﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KalitimOrnek1
{
    public class Ata
    {
        public string ataAlan="ata sınıfı alan değeri";
        public void  AtaMetot(string deger)
        {
            Console.WriteLine($"Ata sınıf :{deger} ");
        }
        public Ata()
        {
            Console.WriteLine("Ata sınıfı kurucu metot");
        }
    }
}
