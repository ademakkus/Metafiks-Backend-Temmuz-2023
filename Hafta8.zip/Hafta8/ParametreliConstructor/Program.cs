﻿namespace ParametreliConstructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Koordinat koordinat = new Koordinat(10, 20);
            Koordinat koordinat2 = new Koordinat(koordinat);
            Console.ReadKey();
        }
    }
}