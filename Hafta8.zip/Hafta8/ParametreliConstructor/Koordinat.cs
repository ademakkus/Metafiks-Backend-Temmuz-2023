﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParametreliConstructor
{
    public class Koordinat
    {
        private int x;
        private int y;
        public Koordinat() //default constructor
        {
            x = 1;
            y = 1;
            Console.WriteLine($"x={x}, y={y}");
        }
        public Koordinat(int x,int y) //parametreli constructor
        {
            this.x = x;
            this.y = y;

            Console.WriteLine($"x={this.x}, y={this.y}");
        }
        public Koordinat(Koordinat koordinat)  //copy constructor
        {
            this.x = koordinat.x+5;
            this.y = koordinat.y+5;
            Console.WriteLine($"x={this.x}, y={this.y}");
        }
    }
}
