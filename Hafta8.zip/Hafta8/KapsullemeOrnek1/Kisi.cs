﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KapsullemeOrnek1
{
    public class Kisi
    {
        //fields:alanlar
        private string ad;
        private int yas;
        private double maas;
        private string sicilNo;
        //property:özellik, öznitelik. field in uzantısıdır.
        public string Ad
        {
            get { return ad.ToUpper(); } //değer döndürür. değer okumak için kullanılır. return ifadesi olacak
                                         // set { ad = value; }  //değer atama için kullanılır. = olacak
            set
            {
                if (value == null)
                    ad = "Adsız Soyadsız";
                else
                    ad = value;
            }
        }
        public int Yas
        {
            get { return yas; }
            set
            {
                if (value < 0)
                    yas = 0;
                else
                    yas = value;
            }
        }
        public double Maas
        {
            get { return maas; }
            set
            {
                if (value <= 0)
                    maas = 1000.50;
                else
                    maas = value;
            }
        }
        public string SicilNo
        {
            get { return sicilNo; }
            set
            {
                Random random=new Random();
                sicilNo = value.ToString() + "-" + random.Next(1000, 9999);
            }
        }

    }
}
