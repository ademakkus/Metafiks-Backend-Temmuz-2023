﻿namespace KapsullemeOrnek1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Kisi kisi=new Kisi();
            kisi.Ad = "Adem AKKUŞ"; //set bloğu
            Console.WriteLine(kisi.Ad); //get bloğu
            Kisi kisi2=new Kisi();
            kisi2.Ad = null;
            Console.WriteLine(kisi2.Ad);
            Console.WriteLine("------------");
            Kisi kisi3=new Kisi();
            kisi3.Ad = "Harun Yeni";
            kisi3.Yas = 35;
            kisi3.Maas = 10000.345;
            Console.WriteLine(kisi3.Ad);
            Console.WriteLine(kisi3.Yas);
            Console.WriteLine(kisi3.Maas);
            kisi3.SicilNo = "AD";
            Console.WriteLine(kisi3.SicilNo);

            Console.ReadKey();
        }
    }
}