﻿namespace KalitimiOrnek2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Ata ata=new Ata("ata nesnesi mesajı");
            Cocuk cocuk = new Cocuk("cocuk nesne mesajı");
            
            Console.ReadKey();
        }
    }
}