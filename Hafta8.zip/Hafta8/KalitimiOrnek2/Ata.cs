﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KalitimiOrnek2
{
    public class Ata
    {
        public Ata()
        {
            
            Console.WriteLine("Ata sınıfı varsayılan kurucu metot.");
        }
        public Ata(string mesaj)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Kurucu metot mesaj:{mesaj}");
        }
    }
    public class Cocuk : Ata
    {
        public Cocuk()
        {
            
            Console.WriteLine("Çocuk sınıfı varsayılan kurucu metot.");
        }
        public Cocuk(string mesaj):base(mesaj) 
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Cocuk sınıf mesaj:{mesaj}");
        }

    }
}
