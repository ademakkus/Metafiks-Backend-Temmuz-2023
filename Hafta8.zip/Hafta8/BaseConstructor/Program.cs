﻿namespace BaseConstructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
           // Personel personel = new Personel("Harun YENİ");
            Calisan calisan = new Calisan("Harun YENİ", "Makine Mühendisi");
            Calisan calisan2 = new Calisan("Harun YENİ");

            Console.ReadKey();
        }
    }
}