﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseConstructor
{
    public class Calisan:Personel
    {
        public Calisan(string isim,string meslek):base(isim)
        {
            Console.WriteLine($"Çalışanın Mesleği:{meslek}");
        }
        public Calisan(string mesaj):base(mesaj)
        {
           Console.WriteLine(mesaj);
        }
        public Calisan():this("bu mesaj this ile geldi.")
        {

        }
      
    }
}
