﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseConstructor
{
    public class Personel
    {
        //ata sınıf
        public Personel(string isim)
        {
            Console.WriteLine($"Personel Adı:{isim}");
        }
    }
}
