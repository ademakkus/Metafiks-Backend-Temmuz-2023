﻿namespace PropertyOrnek2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Urun urun = new Urun();
            urun.UrunAdi = "Bilgisayar";
            urun.UrunKodu = "BİLG";
            urun.UrunFiyati = 25000.123456;
            Console.WriteLine(urun.UrunAdi);
            Console.WriteLine(urun.UrunKodu);
            Console.WriteLine(urun.UrunFiyati);
            Console.ReadKey();
        }
    }
}