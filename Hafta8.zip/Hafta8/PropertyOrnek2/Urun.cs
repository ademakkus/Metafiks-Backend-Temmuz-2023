﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertyOrnek2
{
    public class Urun
    {
        //fields:alan
        private string urunAdi;
        private string urunKodu;
       private double urunFiyati;
        // properties:özellik, öznitelik
        public string UrunAdi
            {
            get { return urunAdi; }
            set { urunAdi = value; }
            }
        public string UrunKodu
        {
            get { return urunKodu; }
            set
            {
                Random random = new Random();
                urunKodu = value.ToString() + "-" + random.Next(10000, 99999);
            }
        }
        
      //  private double urunFiyati;
        public double UrunFiyati
        {
            get { return urunFiyati; }
            set
            {
                urunFiyati = Math.Round(value, 2);
            }
        }
    }
}
