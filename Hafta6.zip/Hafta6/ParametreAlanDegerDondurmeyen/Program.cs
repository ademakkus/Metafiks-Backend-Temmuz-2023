﻿namespace ParametreAlanDegerDondurmeyen
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //static bir metot içeriisnden ancak 
            //static bir metot çağrılabilir.
            int x, y;
            Console.Write("Birinci sayıyı giriniz:");
            x = Convert.ToInt32(Console.ReadLine());
            Console.Write("İkinci sayıyı giriniz:");
            y = Convert.ToInt32(Console.ReadLine());
            //Topla(12, 33); //12 ve 33 argüman
            Topla(x, y); //x ve y argüman
            Cikar(x, y);
            Carp(x, y);
            Bol(x,y);
            Modal(x,y);
            Console.ReadKey();
        }
        static void Topla(int x, int y) //x ve y parametre
        {
            int toplam = x + y;
            Console.WriteLine($"{x}+{y}={toplam}");
        }
        static void Cikar(int x, int y) //x ve y parametre
        {
            int fark = x - y;
            Console.WriteLine($"{x}-{y}={fark}");
        }
        static void Carp(int x, int y) //x ve y parametre
        {
            int carpim = x * y;
            Console.WriteLine($"{x}*{y}={carpim}");
        }
        static void Bol(int x, int y) //x ve y parametre
        {
            int bolme = x / y;
            Console.WriteLine($"{x}/{y}={bolme}");
        }
        static void Modal(int x, int y) //x ve y parametre
        {
            int mod = x % y;
            Console.WriteLine($"{x}-{y}={mod}");
        }

    }
}