﻿namespace RefKullanimi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x =19;
            Console.WriteLine(x);
            Degistir(ref x);
            Console.WriteLine(x);
            Console.ReadKey();
        }
        static void Degistir(ref int x)
        {
            x = 50;
            Console.WriteLine(x);
        }
    }
}