﻿namespace TupleOrnek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            (string, string, double) demet1;
            demet1 = ("Adem AKKUŞ", "Bilgisayra Müh.", 23000);
            (string, string, double) demet2 = ("Elif Tuzluca", "Yazılım Müh.", 25000);
            (string adi, string meslek, double maas) demet3 = ("Harun YENİ", "Makine Müh.", 30000);
            Console.WriteLine(demet2.Item1);
            Console.WriteLine(demet2.Item2);
            Console.WriteLine(demet2.Item3);

            Console.WriteLine(demet3.adi);
            Console.WriteLine(demet3.meslek);
            Console.WriteLine(demet3.maas);
            Console.WriteLine(demet1==demet2);
            Console.ReadKey();
        }
    }
}