﻿namespace MetotDonusTipiTuple
{
    internal class Program
    {
        static void Main(string[] args)
        {
            (string ad, string meslek, double maas) donen = TupleDondur();
            Console.WriteLine($"Adınız:{donen.ad}");
            Console.WriteLine($"Mesleğiniz:{donen.meslek}");
            Console.WriteLine($"Maaşınız:{donen.maas}");

            Console.ReadKey();
        }
        static (string ad, string meslek, double maas) TupleDondur()
        {
            string name, job;
            double salary;
            Console.Write("Adınızı Giriniz:");
            name = Console.ReadLine();
            Console.Write("Mesleğinizi giriniz:");
            job= Console.ReadLine();
            Console.Write("Maaşınızı giriniz:");
            salary=Convert.ToDouble(Console.ReadLine());

            return (name, job, salary);

        }
    }
}