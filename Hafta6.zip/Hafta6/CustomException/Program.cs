﻿namespace CustomException
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //öğrenci notu 0 - 100  aralığında olmalıdır.
            int notu;
            //sbyte -128 ile +127
            Console.Write("Öğrenci notu giriniz:");
            notu = Convert.ToInt32(Console.ReadLine());
            if(notu<0 || notu>100)
                throw new OverflowException("öğrenci notu 0 - 100 aralığında olmalıdır.");
            Console.WriteLine($"Öğrenci notu={ notu} ");
            Console.ReadKey();
        }
    }
}