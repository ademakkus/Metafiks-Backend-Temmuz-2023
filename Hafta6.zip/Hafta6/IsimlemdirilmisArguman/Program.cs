﻿namespace IsimlemdirilmisArguman
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BilgileriYazdir("Adem AKKUŞ","Bilgisayar Müh.",40,'E');
            BilgileriYazdir(meslek: "Bilgisayar Müh", yas: 40, adsoyad: "Adem AKKUŞ", cinsiyet: 'E');
            BilgileriYazdir(cinsiyet: 'E',meslek: "Bilgisayar Müh", yas: 40, adsoyad: "Adem AKKUŞ");

            Console.ReadKey();
        }
        static void BilgileriYazdir(string adsoyad,string meslek,int yas,char cinsiyet)
        {
            Console.WriteLine("-- KİŞİ BİLGİLERİ EKRANI--");
            Console.WriteLine($"Ad Soyad:{adsoyad}");
            Console.WriteLine($"Meslek:{meslek}");
            Console.WriteLine($"Yaş:{yas}");
            Console.WriteLine($"Cinsiyet:{cinsiyet}");
        }
    }
}