﻿namespace ParametreAlmayanDegerDondurmeyen
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
            int sonuc=Topla();
            Console.WriteLine(sonuc);
            Cikar();
            Console.ReadKey();
        }
        //static void Topla()
        //{
        //    int x, y,toplam;
        //    Console.Write("Birinci sayıyı giriniz:");
        //    x = Convert.ToInt32(Console.ReadLine());
        //    Console.Write("İkinci sayıyı giriniz:");
        //    y = Convert.ToInt32(Console.ReadLine());
        //    toplam = x + y;
        //    Console.WriteLine($"{x}+{y}={toplam}");
        //}
        static int Topla()
        {
            int x, y,toplam;
            Console.Write("Birinci sayıyı giriniz:");
            x = Convert.ToInt32(Console.ReadLine());
            Console.Write("İkinci sayıyı giriniz:");
            y = Convert.ToInt32(Console.ReadLine());
            toplam = x + y;
            return toplam;
        }
        static void Cikar()
        {
            
            int x, y,fark;
            Console.Write("Birinci sayıyı giriniz:");
            x = Convert.ToInt32(Console.ReadLine());
            Console.Write("İkinci sayıyı giriniz:");
            y = Convert.ToInt32(Console.ReadLine());
            fark = x - y;
            Console.WriteLine($"{x}-{y}={fark}");
            
        }
        void Yazdir()
        { 
            Console.WriteLine("merhaba");
        }
        int hesapla()
        {
            Topla();
            Yazdir();
            return 1;
        }
    }
}