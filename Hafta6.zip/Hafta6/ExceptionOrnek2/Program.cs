﻿namespace ExceptionOrnek2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int sayi;
            try
            {
                Console.Write("Bir sayı giriniz:");
                sayi = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception exc)
            {
                Console.WriteLine($"Hata Mesajı:{exc.Message}");
                Console.WriteLine($"Hataya sebep olan nesne :{exc.Source}");
                Console.WriteLine($"StackTrace :{exc.StackTrace}");
                Console.WriteLine(exc.Data);
            }

            finally
            {
                Console.WriteLine("her durumda çalışır");
            }
            Console.ReadKey();
        }
    }
}