﻿namespace RekursifOrnej
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int sayi;
            Console.Write("Faktoriyeli alınacak sayıyı giriniz:");
            sayi = Convert.ToInt32(Console.ReadLine());
            long sonuc = FaktoriyelHesapla(sayi);
            Console.WriteLine($"{sayi} nın faktoriyeli={sonuc}");
            Console.WriteLine($"{sayi}!={sonuc}");
            Console.ReadKey();
        }
        static long FaktoriyelHesapla(int sayi)
        {
            long faktoriyel = 1; //en küçük faktoriyel 0!=1
            if (sayi == 0 || sayi == 1)
                return faktoriyel;
            else
                faktoriyel = sayi * FaktoriyelHesapla(sayi - 1);
            return faktoriyel;

        }
    }
}