﻿namespace DegerTipParametre
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //metot tanımlamda parantez içerisinde yazılan değişkenlere PARAMETRE
            //metot çağrılırken parantez içerisine yazılan değişken(ler)/değer(ler) e ARGÜMAN
            int sayi = 19;
            Console.WriteLine($"Main metodu içerisinde sayı={sayi}");
            Degistir(sayi);
            Console.WriteLine($"Degistir çağrıldıktan sonra Main içerisindeki sayı:{sayi}");
            Console.ReadKey();
        }
        static void Degistir(int sayi)
        {
            sayi = 20;
            Console.WriteLine($"Degistir metodundali sayi={sayi}");
        }
    }
}