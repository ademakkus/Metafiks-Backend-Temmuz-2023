﻿namespace ExceptionOrnek3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            byte sayi;
            try
            {
                Console.Write("Bir sayı giriniz:");
                sayi = Convert.ToByte(Console.ReadLine());
                int result = sayi / 0;
            }
            catch (OverflowException oexc)
            {
                Console.WriteLine("Sayı değeri 0 - 255 aralığında olmalıdır.");
                Console.WriteLine($"Orjinal hata mesajı:{oexc.Message}");
            }
            catch (FormatException fexc)
            {
                Console.WriteLine("Lütfen! Bir sayı giriniz");
                Console.WriteLine($"Orjinal hata mesajı:{fexc.Message}");
            }
            catch(DivideByZeroException dexc)
            {
                Console.WriteLine("payda sıfır olamaz.");
                Console.WriteLine($"Orjinal hata mesajı:{dexc.Message}");
            }
            finally
            {

            }
            Console.ReadKey();
        }
    }
}