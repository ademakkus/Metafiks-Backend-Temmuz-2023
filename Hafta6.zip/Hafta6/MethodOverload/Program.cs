﻿namespace MethodOverload
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Topla(3, 4);
            Topla(3.2, 4.2);
            Console.ReadKey();
        }
       
        static int Topla(int x, int y)
        {
            return x + y;
        }
        static int  Topla(int x,int y,int z)
        {
            return x + y + z;
        }
        static double Topla(double x, double y)
        {
            return x + y;
        }
        static double Topla(double x,double y,double z)
        {
            return x + y+z;
        }

    }
}