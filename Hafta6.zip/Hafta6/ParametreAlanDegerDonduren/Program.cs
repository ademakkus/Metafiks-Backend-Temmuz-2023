﻿namespace ParametreAlanDegerDonduren
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x, y;
            Console.Write("Birinci sayıyı giriniz:");
            x = Convert.ToInt32(Console.ReadLine());
            Console.Write("İkinci sayıyı giriniz:");
            y = Convert.ToInt32(Console.ReadLine());
            int sonuc= Topla(x, y);
            int sonuc2=Cikar(x, y);
            Console.WriteLine(sonuc);
            Console.WriteLine(sonuc2);
            Console.ReadKey();
        }
        static int Topla(int x,int y)
        {
            int toplam = x + y;
            return toplam;
        }
        static int Cikar(int x,int y)
        {
            int fark = x - y;
            return fark;
        }
    }
}