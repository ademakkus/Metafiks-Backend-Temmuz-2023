﻿namespace DiziDondurenMetot
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] sayilar = SayiDizisiOlustur();
            foreach (int i in sayilar)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
            string[] sehiler = StringDizisiOlustur();
            foreach (var sehir in sehiler)
            {
                Console.Write(sehir+" ");
            }
            Console.ReadKey();
        }


        static int[] SayiDizisiOlustur()
        {
            int[] dizi = { 11, 22, 33, 44, 55 };
            return dizi;
        }
        static string[] StringDizisiOlustur()
        {
            string[] dizi = { "Ankara", "Bursa", "Çorum", "Bitlis", "Kırşehir" };
            return dizi;
        }
    }
}