﻿namespace OptionalArgument
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Yazdir("Adem AKKUŞ", 40,12000); //maas optional argument
            Yazdir("Elif TUZLUCA",25); //maas optional argument
            Yazdir("Harun YENİ",maas:20000); //maas named argument
            Console.ReadKey();
        }

        static void Yazdir(string adsoyad,int yas=18,double maas=1000) //maas optional parametre
        {
            Console.WriteLine("--- KİŞİ BİLGİLERİ ----");
            Console.WriteLine($"Adı :{adsoyad}");
            Console.WriteLine($"Yaşı :{yas}");
            Console.WriteLine($"Maaşı :{maas}");
        }
    }
}