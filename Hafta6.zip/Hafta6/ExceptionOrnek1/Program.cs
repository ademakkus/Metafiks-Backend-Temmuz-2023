﻿namespace ExceptionOrnek1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int s1=19, s2=0;
            byte s3;
            //int sonuc = s1 / s2;
            //Console.WriteLine(sonuc);
            Console.Write("Bir sayı giriniz:");
            s3 = Convert.ToByte(Console.ReadLine());
            Console.WriteLine(s3);

            Console.ReadKey();
        }
    }
}