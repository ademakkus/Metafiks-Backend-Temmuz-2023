﻿namespace DiziParametre
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] sayilar = { 10, 20, 30, 40, 50, 60 };

            DiziYazdir(sayilar);

            Console.ReadKey();
        }
        static void DiziYazdir(int[] sayilar)
        {
            Console.WriteLine(" ----for döngüsü ile yazdirma----");
            for (int i = 0; i < sayilar.Length; i++)
            {
                Console.Write(sayilar[i] + " ");
            }
            Console.WriteLine("\n----foreach döngüsü ile yazdirma----");
            foreach (int sayi in sayilar)
            {
                Console.Write(sayi + " ");
            }
            string[] isimler = { "Adem", "Elif", "Harun", "Muhittin" };
            StringYazdir(isimler);  

        }
        static void StringYazdir(string[] isimler)
        {
            Console.WriteLine();
            foreach (var isim in isimler)
            {
                Console.Write(isim + " ");
            }
        }
    }
}