﻿namespace OutOrnek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x ;
            Degistir(out x);
            Console.WriteLine(x);
            Console.ReadKey();
        }
        static void Degistir(out int x)
        {
            x = 50;
            Console.WriteLine(x);
        }
    }
}