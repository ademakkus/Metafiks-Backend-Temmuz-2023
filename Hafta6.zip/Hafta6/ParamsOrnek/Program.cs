﻿namespace ParamsOrnek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Topla());
            Console.WriteLine(Topla(3));
            Console.WriteLine(Topla(3,4));
            Console.WriteLine(Topla(3,4,5));

            Console.ReadKey();
        }
        //params, değişken sayıda aynı tipten parametreler alan 
        //metotlarda kullanılır.
        static int Topla(params int[] sayilar)
        {
            int toplam = 0;
            if (sayilar.Length == 0) 
            {
                return toplam;

            }
            foreach (int sayi in sayilar)
            {
                toplam += sayi;
            }
            return toplam;
        
        }
    }
}