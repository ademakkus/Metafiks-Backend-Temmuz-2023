﻿namespace ReferansTipParametre
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] isimler = { "Adem", "Elif", "Harun", "Kerem" };
            Console.WriteLine($"Main metodu içerisinde isimler[3]={isimler[3]}");
            ReferansDegistir(isimler);
            Console.WriteLine($"ReferansDegistir çağrıldıktansonra Main metodunda isimler[3]={isimler[3]}");
            Console.WriteLine(  );
            int[] sayilar = { 11, 22, 33,44, 555, 66};
            Console.WriteLine($"Main sayilar[4]={sayilar[4]}");
            Degistir(sayilar);
            Console.WriteLine("----Diziyi yazdıralım----");
            foreach (var sayi in sayilar)
            {
                Console.Write(sayi + " ");
            }
            Console.ReadKey();
        }
        static void ReferansDegistir(string[] isimler)
        {
            isimler[3] = "Muhittin";

            Console.WriteLine($"ReferansDegistir metodunda isimler[3]={isimler[3]}");
        }
        static void Degistir(int[] sayilar)
        {
            sayilar[4] = 55;
            Console.WriteLine($"Degistir sayilar[4]={sayilar[4]}");
        }
    }
}