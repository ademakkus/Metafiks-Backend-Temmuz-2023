﻿namespace RekursifUsluSayi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            long taban, us;
            Console.Write("Tabanı giriniz:");
            taban=Convert.ToInt64(Console.ReadLine());
            Console.Write("Üs değerini giriniz:");
            us=Convert.ToInt64(Console.ReadLine());
            long sonuc=UsAl(us,taban);
            Console.WriteLine($"{taban} üzeri {us}={sonuc}");
            Console.ReadKey();
        }
        static long UsAl(long us,long taban)
        {
            long sonuc=1;
            if (us == 0 && taban != 0)
                return 1;
            sonuc=taban*UsAl(us-1,taban);
            return sonuc;

        }
    }
}